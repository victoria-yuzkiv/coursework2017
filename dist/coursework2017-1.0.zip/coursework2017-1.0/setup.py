# setup.py
from distutils.core import setup
setup(name="coursework2017",
      version="1.0",
      py_modules=[],
      packages=['modules', 'examples'],
      scripts=['my_research.py'],
      )
